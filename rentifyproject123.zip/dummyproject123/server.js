const http = require('http');

const server = http.createServer((req, res) => {
    if (req.url === '/') {
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(`
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Download Example</title>
                <script src="client.js" defer></script>
            </head>
            <body>
                <h1>Download Page</h1>
                <a id="downloadButton" href="javascript:void(0);">Download File</a>
            </body>
            </html>
        `);
    } else if (req.url === '/client.js') {
        res.writeHead(200, { 'Content-Type': 'application/javascript' });
        res.end(`
            document.addEventListener('DOMContentLoaded', function() {
                const downloadButton = document.getElementById('downloadButton');
                
                if (downloadButton) {
                    downloadButton.addEventListener('click', function() {
                        console.log('Download button clicked');
                    });
                } else {
                    console.error('Download button not found');
                }
            });
        `);
    } else {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('404 Not Found');
    }
});

server.listen(3000, () => {
    console.log('Server is running on http://localhost:3000');
});
