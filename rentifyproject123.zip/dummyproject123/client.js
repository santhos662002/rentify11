// Simulate a browser environment using jsdom
const { JSDOM } = require('jsdom');
const { document } = new JSDOM('').window;
global.document = document;

// Define the function in the global scope
function closeDescriptionPopup() {
    console.log("Closing description popup");
    // Add logic to close the popup here
}

// Ensure the function is attached to the global window object
if (typeof window !== 'undefined') {
    window.closeDescriptionPopup = closeDescriptionPopup;
}

// Your client-side logic
document.addEventListener('DOMContentLoaded', function() {
    // Seller Dashboard Logic
    if (document.getElementById('propertyForm')) {
        document.getElementById('propertyForm').addEventListener('submit', function(e) {
            e.preventDefault();
            // Post property logic here
            console.log('Property form submitted');
        });

        // Fetch and display seller properties
        // Fetch properties logic here
        console.log('Fetching seller properties');
    }

    // Buyer Dashboard Logic
    if (document.getElementById('filterForm')) {
        document.getElementById('filterForm').addEventListener('submit', function(e) {
            e.preventDefault();
            // Apply filters logic here
            console.log('Filter form submitted');
        });

        // Fetch and display properties
        // Fetch properties logic here
        console.log('Fetching buyer properties');
    }

    // Example usage of the closeDescriptionPopup function
    const closeButton = document.getElementById('closeButton');
    if (closeButton) {
        closeButton.addEventListener('click', function() {
            // Call the closeDescriptionPopup function
            closeDescriptionPopup();
        });
    }
});
