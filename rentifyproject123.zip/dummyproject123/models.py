from django.db import models
from django.contrib.auth.models import User

class Property(models.Model):
    title = models.CharField(max_length=200)
    place = models.CharField(max_length=200)
    area = models.FloatField()
    bedrooms = models.IntegerField()
    bathrooms = models.IntegerField()
    nearby = models.TextField()
    seller = models.ForeignKey(User, on_delete=models.CASCADE, related_name='properties')

    def __str__(self):
        return self.title

class Interest(models.Model):
    property = models.ForeignKey(Property, on_delete=models.CASCADE, related_name='interests')
    buyer = models.ForeignKey(User, on_delete=models.CASCADE, related_name='interests')
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.buyer} interested in {self.property}"
